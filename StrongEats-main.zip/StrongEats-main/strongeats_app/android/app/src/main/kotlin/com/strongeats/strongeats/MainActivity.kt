package com.strongeats.strongeats

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
