# StrongEats
CIS454 Project

“The App that does everything except the workout for you” 
This is an app that revolutionizes the workout world.
It gives the user all the control they need and allows them to find ways to stay fit and achieve their workout goals with as little stress as possible.
From a specified workout plan, nutrition program, and scheduled workout times, Strong Eats is the ideal for the anyone trying to stay active and achieve their workout goals.
Once you tell the app your goals, all you have to do is focus on working out and being you. 
